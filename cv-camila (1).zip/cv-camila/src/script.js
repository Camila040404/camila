const cv = {

about:"Hola 👋 Soy Camila De La Rosa. Me apasiona la tecnología y crear páginas web modernas y bonitas.",

experience:[
"💻 Desarrolladora Web Junior (2024 - Actualidad)",
"🎨 Proyectos personales de diseño web"
],

education:[
"🎓 Estudios en Desarrollo Web",
"📚 Curso de HTML, CSS y JavaScript"
],

skills:[
"HTML",
"CSS",
"JavaScript",
"Diseño Web",
"Creatividad",
"Trabajo en equipo"
],

contact:"📧 camila@email.com | 💼 LinkedIn | 💻 GitHub"

};

document.getElementById("about").textContent=cv.about;
document.getElementById("contact").textContent=cv.contact;

const exp=document.getElementById("experience");
cv.experience.forEach(e=>{
const li=document.createElement("li");
li.textContent=e;
exp.appendChild(li);
});

const edu=document.getElementById("education");
cv.education.forEach(e=>{
const li=document.createElement("li");
li.textContent=e;
edu.appendChild(li);
});

const skills=document.getElementById("skills");
cv.skills.forEach(s=>{
const span=document.createElement("span");
span.textContent=s;
skills.appendChild(span);
});